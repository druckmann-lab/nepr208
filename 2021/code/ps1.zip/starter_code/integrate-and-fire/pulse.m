%% Generates a current pulse
%  [time, current, stim_length] = pulse(dt, amplitude)
%  Niru Maheswaranathan
%  May 6 2016

function [time, current, stim_length] = pulse(dt, amplitude)

  % Current injection protocol
  % -- note: you may wish to modify these parameters to change the length of the current pulse
  I_start = 200;          % Start of injection (ms)
  I_stop = 800;           % End of injection (ms)
  t_end = 1000;           % total time (ms)

  % store the length of the pulse in seconds (useful for computing the firing rate)
  stim_length = (I_stop - I_start) / 1000;

  % Initialization (we shift the time axis so that t=0ms is the start of the current injection)
  time = (0:dt:t_end) - I_start;
  current = zeros(length(time), 1);

  % Get the indices of when to apply the current pulse, and set the amplitude
  i0 = ceil(I_start / dt);
  i1 = ceil(I_stop / dt);
  current(i0:i1) = amplitude;

end
