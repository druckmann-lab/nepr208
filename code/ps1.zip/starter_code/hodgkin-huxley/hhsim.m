% Specify the properties of ion channels embedded in the membrane
%%%
%    YOUR CODE HERE
%    use the make_channel.m function to create a struct representing the ion
%    channel population for the sodium and potassium ions. We've written a line
%    that creates the channel population for the leak conductance below
%
%    use the following parameters when creating these ion channel species:
%    sodium: E_Na=50 mV, g_max=1200 muS
%    potassium: E_K=-77 mV, g_max=360 muS
%%%
leak = make_channel(-54.387, 3);    % E_leak = -54.387 mV,  g_max = 3 muS

% Specify the membrane parameters
Cm = 10;  % nF/mm^2;

% Simulation time
dt = 0.05;                 % integration time step (s)

% Current injection protocol
% -- note: feel free to play around with the injected current amplitude
I_value = 200;            % injection strength (nA)

% std. deviation of the noise
% -- note: feel free to play around with noise strength
I_noise = 50;

% generate a current pulse
[time, current, stim_length] = pulse(dt, I_value);

% initial conditions
voltage = zeros(length(time), 1); voltage(1) = -64.996;
m = zeros(length(time), 1); m(1) = 0.052955;
n = zeros(length(time), 1); n(1) = 0.31773;
h = zeros(length(time), 1); h(1) = 0.59599;

% run the simulation
for t = 2:length(time)

  % update gating variables
  [alpha, beta] = gates(voltage(t-1));
  %%%
  %   YOUR CODE HERE
  %   write code to update the state of the gating variables: m, n, and h
  %%%

  % compute the total input current to the neuron
  %%%
  %   YOUR CODE HERE
  %   Compute the total current entering the neuron
  %   note that this current consists of:
  %     - current through each of the ion channels (leak, Na, K) according to the HH equations
  %     - noise (add gaussian noise with a standard deviation given by I_noise)
  %     - note: you can try simulating it without noise first, and then add the noise later
  %   total_current = ???
  %%%

  % update the membrane potential
  %%%
  %   YOUR CODE HERE
  %   use the discretized approximation to compute the voltage at the next time step given the
  %   value of the voltage at the current time step and the total_current computed above
  %   voltage(t) = ???
  %%%

end

subplot(211);
plot(time, current);
subplot(212);
plot(time, voltage);
