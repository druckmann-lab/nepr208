%% Computes equations for the gating variables
%  [alpha, beta] = gates(v)
%  Niru Maheswaranathan
%  May 4 2016

function [alpha, beta] = gates(v)

  % alpha
  alpha = struct();
  alpha.m = 0.1 * (v + 40) ./ (1 - exp(-0.1 * (v + 40)));
  alpha.n = 0.01 * (v + 55) ./ (1 - exp(-0.1 * (v + 55)));
  alpha.h = 0.07 * exp(-0.05 * (v + 65));

  % beta
  beta = struct();
  beta.m = 4 * exp(-0.0556 * (v + 65));
  beta.n = 0.125 * exp(-0.0125 * (v + 65));
  beta.h = 1 ./ (1 + exp(-0.1 * (v + 35)));

end
