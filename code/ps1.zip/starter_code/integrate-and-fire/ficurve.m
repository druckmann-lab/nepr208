%% Simulation to generate an F-I curve
%  rates = ficurve(amplitudes, cell, dt)
%  Niru Maheswaranathan
%  May 4 2016

function rates = ficurve(amplitudes, cell, dt)

  % store the firing rates in a vector
  rates = zeros(length(amplitudes), 1);

  for idx = 1:length(amplitudes)

    %%%
    %    YOUR CODE HERE - use the pulse.m function to generate a current pulse with the appropriate amplitude
    %%%

    %%%
    %    YOUR CODE HERE - use the integrate.m function to compute the voltage and the number of spikes
    %%%

    % compute the firing rate and store it
    rates(idx) = nspikes / stim_length;

  end

end
