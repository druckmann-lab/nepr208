%% Integrate and fire neuron script
%  Niru Maheswaranathan
%  May 4 2016

% Cell parameters
cell = struct();
cell.C = 1;             % Membrane capacitance (nF)
cell.g = 0.1;           % Membrane or leak conductance (uS)
cell.Vrest = -65;       % Resting potential (mV)
cell.Vth = -56;         % Spiking threshold (mV)
cell.Vreset = -65;      % Voltage reset (mV)
cell.Vspike = 20;       % Spiking voltage (mV) (for visualization purposes)

% current pulse protocol
dt = 1;                 % simulation time step (ms)
amplitude = 1.1;        % applied current (nA)
%%%
%    YOUR CODE HERE - use the pulse.m function to generate a current pulse
%%%

% run the integration
%%%
%    YOUR CODE HERE - use the integrate.m function to simulate the integrate-and-fire neuron
%%%

% compute the firing rate
firing_rate = nspikes / stim_length;

% visualization
plot(time, voltage)
