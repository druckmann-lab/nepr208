%% Simulates an integrate and fire neuron
%  [voltage, nspikes] = integrate(current, dt, time, cell)
%  Niru Maheswaranathan
%  May 4 2016

function [voltage, nspikes] = integrate(current, dt, time, cell)

  % initialize voltage
  voltage = zeros(length(time), 1);
  voltage(1) = %%% YOUR CODE HERE - initialize the voltage to the resting potential of the cell %%%

  % counter for the number of spikes
  nspikes = 0;

  % run the integration
  for t = 2:length(time)

    % compute the total current entering the cell
    %%%
    %    YOUR CODE HERE - compute the total current entering the cell
    %    total_current = ???
    %%%

    % the voltage update equation
    %%%
    %    YOUR CODE HERE - compute the membrane voltage at the next time step
    %    voltage(t) = ???
    %%%

    % spiking mechanism: check if the voltage has crossed threshold
    if voltage(t) > cell.Vth

      % reset the membrane voltage
      voltage(t) = cell.Vreset;

      % (for visualization purposes) set the voltage to the spiking value
      % -- note: this is just here so that when we plot the voltage we can see the spikes
      voltage(t-1) = cell.Vspike;

      % increment the number of spikes
      nspikes = nspikes + 1;

    end

  end
