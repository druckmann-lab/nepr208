%% STDP in a network of Izhikevich neurons
%
% Modified by Niru Maheswaranathan, 4/17/17
% Created by Eugene M. Izhikevich, February 25, 2003
% STDP added by Gaia Silvestri 2013 (https://github.com/gaiasilvestri/spike-time-dependent-plasticity)
clear all;

%% --------------------
%  Network parameters

% STDP parameters
A_plus = 0.9;
tau_plus = 20.0;
A_minus = 0.925;
tau_minus = 20.0;

% weight scale for drawing the initial weights
weight_scale = 0.0;

% fraction of non-zero synapses
p=0.7;                  % 30% of zero-weight synapses when p=0.7

% when to 'turn on' plasticity
plasticity=2500;          % Plastic changes happen after this time (ms)
%  --------------------

%% --------------------
%  Build the network

% Excitatory neurons    Inhibitory neurons
Ne=800;                 Ni=200;

% total number of neurons
n_total=Ne+Ni;

% parameters of the Izhikevich neurons
% (see https://www.izhikevich.org/publications/spikes.htm for details)
a=[0.02*ones(Ne,1);     0.1*ones(Ni,1)];
b=[0.2*ones(Ne,1);      0.2*ones(Ni,1)];
c=[-65*ones(Ne,1);      -65*ones(Ni,1)];
d=[8*ones(Ne,1);        2*ones(Ni,1)];

runtime=2000;           % Runtime in ms
v=-65*ones(Ne+Ni,1);    % Initial values of v
u=b.*v;                 % Initial values of u
firings=[];             % store spike timings
ADJ=zeros(runtime,n_total);

% initial weight distribution
% - randomly draws weights from uniform distributions
S=[weight_scale*rand(Ne+Ni,Ne),  -weight_scale*rand(Ne+Ni,Ni)];

% - zeroes out weights randomly so that the connectivity is sparse
M=rand(n_total,n_total);
for ii=1:n_total
    for jj=1:n_total
        if ii==jj
             S(ii,jj)=0; %no self connections
        elseif M(ii,jj)>p
             S(ii,jj)=0;
        end
    end
end

figure(2); subplot(211);
weights = S(S ~= 0);
hist(weights, 50);
title('Initial weight distribution');
%  --------------------


%% --------------------
%  Simulate the network
for t=1:runtime                    % simulation of runtime in ms
  I=[5*randn(Ne,1);2*randn(Ni,1)]; % thalamic input (random inputs)
  fired=find(v>=30);               % find indices of spikes
  for jj=1:numel(fired)
      ADJ(t,fired(jj))=1;          % Record which neurons fire at each ms
  end
  if t>plasticity        % whether or not to run the plasticity rule
      for j=1:n_total
        if ADJ(t,j)==1   %neuron j fired at time t

					% range of ms over which synaptic strengthening and weakening occur
          for x=1:2*max(tau_plus, tau_minus)
              for k=1:n_total
                if ADJ(t-x,k)==1  % find out which neurons fired in the previous 20 ms

                  % --------------------
									% STDP update rule

                  % increase synaptic weight if pre before post
                  S(j,k)=S(j,k).*(1+A_plus*exp(x/tau_plus));

                  % decrease synaptic weight if post before pre
                  S(k,j)=S(k,j).*(1-A_minus*exp(-x/tau_minus));
                  % --------------------

                  % set a maximum value for synaptic weights
									% (clips weights larger than gmax)
									gmax = 2.0;
                  if S(j,k)>gmax
                      S(j,k)=gmax;
                  end
                  if S(j,k)<-gmax
                      S(j,k)=-gmax;
                  end
                  if S(k,j)>gmax
                      S(k,j)=gmax;
                  end
                  if S(k,j)<-gmax
                      S(k,j)=-gmax;
                  end
                end
              end
          end
        end
      end
  end

	% store times of spikes
	% left column is the spike time, right is index of neuron firing out of n_total.
  firings=[firings; t+0*fired,fired];

	% spike reset mechanism (for the Izhikevich neuron model)
  v(fired)=c(fired);
  u(fired)=u(fired)+d(fired);

	% numerical integration of the Izhikevich neuron model
  I=I+sum(S(:,fired),2);
  v=v+0.5*(0.04*v.^2+5*v+140-u+I); % step 0.5 ms
  v=v+0.5*(0.04*v.^2+5*v+140-u+I); % for numerical stability
  u=u+a.*(b.*v-u);                 % update u
end


% plot raster of spike times
figure(1); clf; hold on;
plot(firings(:,1),firings(:,2),'.');
plot([plasticity plasticity], [0 n_total], 'r--', 'linewidth', 3);
ylim([0 n_total]);
xlim([0 runtime]);
title('Spike raster - STDP in a random network');

% Plot final weight distributions
figure(2); subplot(212);
weights = S(S ~= 0);
hist(weights, 50);
title('Final weight distribution');
