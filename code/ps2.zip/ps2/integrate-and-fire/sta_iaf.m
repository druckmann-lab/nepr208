%% Integrate and fire neuron
%  Niru Maheswaranathan
%  May 4 2016

% Cell parameters
cell = struct();
cell.C = 1;             % Membrane capacitance (nF)
cell.g = 0.1;           % Membrane or leak conductance (uS)
cell.Vrest = -65;       % Resting potential (mV)
cell.Vth = -56;         % Spiking threshold (mV)
cell.Vreset = -65;      % Voltage reset (mV)
cell.Vspike = 20;       % Spiking voltage (mV) (for visualization purposes)
cell.noise = 0.0;       % Std. deviation of voltage fluctuations (mV)

% time array
t_end = 10000;           % end time (ms)
dt = 0.1;              % simulation time step (ms)
time = 0:dt:t_end;

% current pulse
sigma = % [[ YOUR CODE HERE ]]    % std. deviation of the applied current (nA)

% generate a white noise current input with the given standard deviation, where
% the current at each time point is drawn from a normal distribution with zero
% mean and standard deviation given by sigma
current =  % [[ YOUR CODE HERE ]]

% run the integration
filter_length = 200; % ms
tau = 0:dt:(filter_length*dt-dt);
[voltage, nspikes, sta] = integrate(current, dt, time, cell, filter_length);

% compute the firing rate
firing_rate = nspikes / (t_end / 1000);

hold on;
plot(tau, flipud(sta));

% visualization
subplot(3, 1, 1)
plot(time, current, 'k-');
xlim([time(1) time(end)]);
ylabel('Current (nA)');
set(gca, 'xtick', []);
makepretty;
subplot(3, 1, [2,3])
plot(time, voltage, '-');
xlim([time(1) time(end)]);
ylim([-80, 30]);
makepretty;
title(['Firing Rate: ', num2str(firing_rate), ' Hz'], 'fontweight', 'Normal');
ylabel('Voltage (mV)');
xlabel('Time (ms)');
