%% Simulates an integrate and fire neuron
%  [voltage, nspikes] = integrate(current, dt, time, cell)
%  Niru Maheswaranathan
%  May 4 2016

function [voltage, nspikes, sta] = integrate(current, dt, time, cell, filter_length)

  % initialize voltage
  voltage = zeros(length(time), 1);
  voltage(1) = cell.Vrest;

  % counter for the number of spikes
  nspikes = 0;
  sta = zeros(filter_length, 1);

  % run the integration
  for t = 2:length(time)

    % compute the total current entering the cell
    total_current = current(t) - cell.g * (voltage(t-1) - cell.Vrest);

    % the voltage update equation
    voltage(t) = voltage(t-1) + (dt / cell.C) * total_current + cell.noise * randn;

    % spiking mechanism: check if the voltage has crossed threshold
    if voltage(t) > cell.Vth

      % reset the membrane voltage
      voltage(t) = cell.Vreset;

      % (for visualization purposes) set the voltage to the spiking value
      voltage(t-1) = cell.Vspike;

      % increment the number of spikes
      nspikes = nspikes + 1;

      % add to the sta
      if t >= filter_length
        sta = sta + current(t-filter_length+1:t);
      end

    end

  end

  sta = sta / nspikes;

end
