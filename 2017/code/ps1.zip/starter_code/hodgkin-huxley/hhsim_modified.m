% Specify the properties of ion channels embedded in the membrane
Na = make_channel(50, 1.2e3);
NaP = make_channel(50, 0.05);
K = make_channel(-77, 0.36e3);
LCa = make_channel(134, 0.1);
leak = make_channel(-54.387, 3);    % E_leak = -54.387 mV,  g_max = 3 muS

% Specify the membrane parameters
Cm = 10;  % nF/mm^2;

% Simulation time
dt = 0.05;                 % integration time step (s)

% Current injection protocol
% -- note: feel free to play around with the injected current amplitude
I_value = 200;            % injection strength (nA)

% std. deviation of the noise
% -- note: feel free to play around with noise strength
I_noise = 50;

% generate a current pulse
[time, current, stim_length] = pulse(dt, I_value);

% initial conditions
voltage = zeros(length(time), 1); voltage(1) = -64.996;
m = zeros(length(time), 1); m(1) = 0.052955;
n = zeros(length(time), 1); n(1) = 0.31773;
h = zeros(length(time), 1); h(1) = 0.59599;
q = zeros(length(time), 1); q(1) = 0.0;
r = zeros(length(time), 1); r(1) = 0.0;

% run the simulation
for t = 2:length(time)

  % update gating variables
  [alpha, beta] = gates(voltage(t-1));
  m(t) = m(t-1) + dt * (alpha.m * (1-m(t-1)) - beta.m * m(t-1));
  n(t) = n(t-1) + dt * (alpha.n * (1-n(t-1)) - beta.n * n(t-1));
  h(t) = h(t-1) + dt * (alpha.h * (1-h(t-1)) - beta.h * h(t-1));
  q(t) = q(t-1) + dt * (alpha.q * (1-q(t-1)) - beta.q * q(t-1));
  r(t) = r(t-1) + dt * (alpha.r * (1-r(t-1)) - beta.r * r(t-1));

  % calcium current
  I_ca = LCa.gmax * q(t-1)^2 * r(t-1) * (LCa.E - voltage(t-1));

  % update membrane potential
  total_current = current(t-1) + ...
                  I_noise * randn + ...
                  leak.gmax * (leak.E - voltage(t-1)) + ...
                  Na.gmax * m(t-1)^3 * h(t-1) * (Na.E - voltage(t-1)) + ...
                  NaP.gmax * m(t-1) * (NaP.E - voltage(t-1)) + ...
                  K.gmax * n(t-1)^4 * (K.E - voltage(t-1)) + ...
                  I_ca;

  voltage(t) = voltage(t-1) + (dt / Cm) * total_current;

end

subplot(211);
plot(time, current);
subplot(212);
plot(time, voltage);
